#!/bin/sh
~/cc/cc/config.json
